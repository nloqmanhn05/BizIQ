export function Decisions() {
  return (
    <>
      <div className="mb-8">
        <h1 className="font-display-sm text-3xl md:text-4xl text-on-surface mb-2">3 recommendations based on your data</h1>
        <p className="font-body-lg text-on-surface-variant max-w-3xl">Review these automated insights to optimize your operational efficiency.</p>
      </div>

      <div className="flex flex-col gap-6">
        {/* Card 1: Critical/High Value */}
        <div className="bg-surface-container-lowest shadow-sm rounded-xl border-l-4 border-error hover:bg-surface-container-low transition-colors group cursor-pointer relative overflow-hidden flex flex-col sm:flex-row gap-6 p-6 border-y border-r border-outline-variant/30">
          <div className="flex-1 flex flex-col justify-between">
            <div>
              <div className="flex items-start justify-between mb-2">
                <h3 className="font-title-lg text-xl font-medium text-on-surface">Reduce supplier costs by 14%</h3>
                <div className="hidden sm:flex items-center gap-1 bg-surface rounded-full px-3 py-1 border border-outline-variant">
                  <span className="material-symbols-outlined text-[16px] text-primary">psychiatry</span>
                  <span className="font-label-lg text-xs font-semibold text-primary">98% Confidence</span>
                </div>
              </div>
              <p className="font-body-lg text-on-surface-variant mb-4">
                Analysis of Q3 procurement data indicates overlapping contracts with Logistics Inc. and FastFreight. Consolidating vendors can yield immediate savings.
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-2 mt-auto">
              <div className="inline-flex items-center gap-2 bg-primary-container text-on-primary-container px-4 py-1.5 rounded-full font-label-lg text-sm font-semibold">
                <span className="material-symbols-outlined text-[18px]">trending_down</span>
                Est. Savings: $1.2M/yr
              </div>
              <div className="inline-flex items-center gap-2 border border-outline-variant bg-surface text-on-surface-variant px-3 py-1.5 rounded-lg font-label-lg text-sm">
                <span className="material-symbols-outlined text-[16px]">schedule</span>
                Implementation: 2 Weeks
              </div>
            </div>
          </div>
          <div className="flex sm:flex-col items-center justify-between sm:justify-center border-t sm:border-t-0 sm:border-l border-outline-variant/50 pt-4 sm:pt-0 sm:pl-6 shrink-0">
            <button className="bg-primary hover:opacity-90 text-on-primary rounded-full px-6 py-2.5 font-label-lg text-sm font-medium transition-colors flex items-center gap-2 shadow-sm">
              Review Action
              <span className="material-symbols-outlined text-[18px]">arrow_forward</span>
            </button>
          </div>
        </div>

        {/* Card 2: Medium Value */}
        <div className="bg-surface-container-lowest shadow-sm rounded-xl border-l-4 border-tertiary-container hover:bg-surface-container-low transition-colors group cursor-pointer relative overflow-hidden flex flex-col sm:flex-row gap-6 p-6 border-y border-r border-outline-variant/30">
          <div className="flex-1 flex flex-col justify-between">
            <div>
              <div className="flex items-start justify-between mb-2">
                <h3 className="font-title-lg text-xl font-medium text-on-surface">Switch to Paperless Billing</h3>
                <div className="hidden sm:flex items-center gap-1 bg-surface rounded-full px-3 py-1 border border-outline-variant">
                  <span className="material-symbols-outlined text-[16px] text-tertiary">psychiatry</span>
                  <span className="font-label-lg text-xs font-semibold text-tertiary">85% Confidence</span>
                </div>
              </div>
              <p className="font-body-lg text-on-surface-variant mb-4">
                42% of your enterprise clients are still receiving physical invoices. Converting them to digital portals reduces administrative overhead and mailing costs.
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-2 mt-auto">
              <div className="inline-flex items-center gap-2 bg-secondary-container/20 text-secondary border border-secondary/20 px-4 py-1.5 rounded-full font-label-lg text-sm font-semibold">
                <span className="material-symbols-outlined text-[18px]">savings</span>
                Est. Savings: $450k/yr
              </div>
            </div>
          </div>
          <div className="flex sm:flex-col items-center justify-between sm:justify-center border-t sm:border-t-0 sm:border-l border-outline-variant/50 pt-4 sm:pt-0 sm:pl-6 shrink-0">
            <button className="bg-surface border border-outline hover:bg-surface-variant text-on-surface rounded-full px-6 py-2.5 font-label-lg text-sm font-medium transition-colors flex items-center gap-2">
              Review Action
            </button>
          </div>
        </div>

        {/* Card 3: Standard */}
        <div className="bg-surface-container-lowest shadow-sm rounded-xl border-l-4 border-outline hover:bg-surface-container-low transition-colors group cursor-pointer relative overflow-hidden flex flex-col sm:flex-row gap-6 p-6 border-y border-r border-outline-variant/30">
          <div className="flex-1 flex flex-col justify-between">
            <div>
              <div className="flex items-start justify-between mb-2">
                <h3 className="font-title-lg text-xl font-medium text-on-surface">Adjust Cloud Storage Plan</h3>
                <div className="hidden sm:flex items-center gap-1 bg-surface rounded-full px-3 py-1 border border-outline-variant">
                  <span className="material-symbols-outlined text-[16px] text-on-surface-variant">psychiatry</span>
                  <span className="font-label-lg text-xs font-semibold text-on-surface-variant">72% Confidence</span>
                </div>
              </div>
              <p className="font-body-lg text-on-surface-variant mb-4">
                Historical usage trends indicate that Tier 1 storage is underutilized by 30%. Downgrading non-critical backups to Cold Storage is recommended.
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-2 mt-auto">
              <div className="inline-flex items-center gap-2 bg-surface-variant text-on-surface-variant px-4 py-1.5 rounded-full font-label-lg text-sm font-semibold border border-outline-variant">
                <span className="material-symbols-outlined text-[18px]">cloud_sync</span>
                Est. Savings: $85k/yr
              </div>
            </div>
          </div>
          <div className="flex sm:flex-col items-center justify-between sm:justify-center border-t sm:border-t-0 sm:border-l border-outline-variant/50 pt-4 sm:pt-0 sm:pl-6 shrink-0">
            <button className="bg-surface border border-outline hover:bg-surface-variant text-on-surface rounded-full px-6 py-2.5 font-label-lg text-sm font-medium transition-colors flex items-center gap-2">
              Review Action
            </button>
          </div>
        </div>
      </div>
    </>
  );
}

export function Upload() {
  return (
    <>
      <section className="flex flex-col gap-2 mb-8">
        <h1 className="font-display-sm text-3xl md:text-4xl text-on-surface">Data Ingestion</h1>
        <p className="font-body-lg text-on-surface-variant max-w-2xl">
          Upload your datasets, financial models, or analytical reports to BizIQ for processing. Supported formats include CSV, XLSX, and PDF.
        </p>
      </section>

      <section className="flex flex-wrap gap-2 mb-8">
        <button className="flex items-center gap-1.5 px-3 py-1.5 border border-outline rounded-lg bg-surface-container-lowest text-on-surface hover:bg-surface-variant transition-colors shadow-sm">
          <span className="material-symbols-outlined text-[18px]">done_all</span>
          <span className="font-label-lg text-sm">All Types</span>
        </button>
        <button className="flex items-center gap-1.5 px-3 py-1.5 border border-outline-variant rounded-lg bg-transparent text-on-surface-variant hover:bg-surface-variant transition-colors">
          <span className="material-symbols-outlined text-[18px]">table_chart</span>
          <span className="font-label-lg text-sm">Spreadsheets</span>
        </button>
        <button className="flex items-center gap-1.5 px-3 py-1.5 border border-outline-variant rounded-lg bg-transparent text-on-surface-variant hover:bg-surface-variant transition-colors">
          <span className="material-symbols-outlined text-[18px]">description</span>
          <span className="font-label-lg text-sm">Documents</span>
        </button>
        <button className="flex items-center gap-1.5 px-3 py-1.5 border border-outline-variant rounded-lg bg-transparent text-on-surface-variant hover:bg-surface-variant transition-colors">
          <span className="material-symbols-outlined text-[18px]">image</span>
          <span className="font-label-lg text-sm">Media</span>
        </button>
      </section>

      <section className="mb-12">
        <div className="w-full bg-surface-container border-2 border-dashed border-outline-variant rounded-[28px] p-8 md:p-16 flex flex-col items-center justify-center text-center transition-colors hover:bg-surface-container-high group cursor-pointer">
          <div className="w-20 h-20 bg-surface-container-lowest rounded-full flex items-center justify-center mb-4 shadow-sm group-hover:scale-105 transition-transform duration-300">
            <span className="material-symbols-outlined text-[40px] text-primary-container" style={{ fontVariationSettings: "'FILL' 1" }}>cloud_upload</span>
          </div>
          <h3 className="font-title-lg text-xl text-on-surface mb-1">Drag and drop files here</h3>
          <p className="font-body-lg text-on-surface-variant mb-6">or click to browse from your device</p>
          
          <button className="bg-primary text-on-primary font-label-lg rounded-full px-6 py-3 flex items-center gap-2 hover:opacity-90 transition-opacity active:scale-95 shadow-sm">
            <span className="material-symbols-outlined text-[20px]">add_circle</span>
            Select Files
          </button>
          
          <p className="font-label-lg text-outline mt-6 text-xs">Maximum file size: 50MB</p>
        </div>
      </section>

      <section>
        <h2 className="font-title-lg text-xl text-on-surface mb-4">Recent Activity</h2>
        <div className="flex flex-col gap-2">
          <div className="flex items-center gap-4 p-4 bg-surface-container-lowest rounded-xl shadow-sm border border-outline-variant/30 hover:bg-surface-container-low transition-colors group cursor-pointer">
            <div className="w-12 h-12 bg-surface-variant rounded-lg flex items-center justify-center text-primary-container">
              <span className="material-symbols-outlined">table_view</span>
            </div>
            <div className="flex-grow min-w-0">
              <p className="font-label-lg font-medium text-on-surface truncate">Q3_Financial_Projections_v2.xlsx</p>
              <p className="font-body-lg text-xs text-on-surface-variant truncate mt-0.5">2.4 MB • Uploaded 2 hours ago</p>
            </div>
            <button className="p-2 text-outline hover:text-on-surface transition-colors rounded-full hover:bg-surface-variant opacity-0 group-hover:opacity-100 focus:opacity-100">
              <span className="material-symbols-outlined">more_vert</span>
            </button>
          </div>
          
          <div className="flex items-center gap-4 p-4 bg-surface-container-lowest rounded-xl shadow-sm border border-outline-variant/30 hover:bg-surface-container-low transition-colors group cursor-pointer">
            <div className="w-12 h-12 bg-error-container rounded-lg flex items-center justify-center text-on-error-container">
              <span className="material-symbols-outlined">picture_as_pdf</span>
            </div>
            <div className="flex-grow min-w-0">
              <p className="font-label-lg font-medium text-on-surface truncate">Market_Analysis_Report_APAC.pdf</p>
              <p className="font-body-lg text-xs text-on-surface-variant truncate mt-0.5">8.1 MB • Uploaded Yesterday</p>
            </div>
            <button className="p-2 text-outline hover:text-on-surface transition-colors rounded-full hover:bg-surface-variant opacity-0 group-hover:opacity-100 focus:opacity-100">
              <span className="material-symbols-outlined">more_vert</span>
            </button>
          </div>
        </div>
      </section>
    </>
  );
}

import React, { useState, useRef, useEffect } from "react";
import { clsx } from "clsx";

interface Message {
  id: string;
  role: "user" | "ai";
  text: string;
}

export function Chat() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "init",
      role: "ai",
      text: "Hello! I am BizIQ Data Assistant. Ask me anything about your revenue, customers, or business operations."
    }
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  const handleSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput("");
    
    const newMsg: Message = { id: Date.now().toString(), role: "user", text: userMessage };
    setMessages(prev => [...prev, newMsg]);
    setIsLoading(true);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: userMessage })
      });
      
      const data = await res.json();
      
      if (!res.ok) {
        throw new Error(data.error || "Failed to generate AI response");
      }

      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        role: "ai",
        text: data.text || "Sorry, I couldn't process your request."
      }]);
    } catch (err) {
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        role: "ai", 
        text: err instanceof Error ? err.message : "Error communicating with AI service."
      }]);
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-64px)] -m-6 md:-m-8 bg-background md:border-l border-outline-variant/30 overflow-hidden shadow-sm">
      <div className="flex-1 overflow-y-auto p-6 md:p-8 flex flex-col gap-8" ref={scrollRef}>
        {messages.map(msg => (
          <div key={msg.id} className={clsx("flex flex-col gap-2 w-full max-w-4xl", msg.role === "user" ? "items-end self-end" : "items-start self-start")}>
            {msg.role === "ai" && (
              <div className="flex items-center gap-2 ml-2 mb-1">
                <div className="w-8 h-8 rounded-full bg-primary text-on-primary flex items-center justify-center">
                  <span className="material-symbols-outlined" style={{ fontVariationSettings: "'FILL' 1" }}>analytics</span>
                </div>
                <span className="font-label-lg text-sm text-primary font-semibold">Data Assistant</span>
              </div>
            )}
            <div className={clsx(
              "p-6 rounded-[28px] text-body-lg",
              msg.role === "user" 
                ? "bg-primary-container text-on-primary-container rounded-tr-sm shadow-sm" 
                : "bg-surface text-on-surface rounded-tl-sm border border-surface-container-highest shadow-sm relative overflow-hidden"
            )}>
              {msg.role === "ai" && <div className="absolute inset-0 bg-primary opacity-5 pointer-events-none"></div>}
              <div className="relative z-10 whitespace-pre-wrap">
                {msg.text}
              </div>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex flex-col items-start gap-2 w-full max-w-4xl self-start">
             <div className="flex items-center gap-2 ml-2 mb-1">
                <div className="w-8 h-8 rounded-full bg-primary text-on-primary flex items-center justify-center">
                  <span className="material-symbols-outlined" style={{ fontVariationSettings: "'FILL' 1" }}>analytics</span>
                </div>
                <span className="font-label-lg text-sm text-primary font-semibold">Data Assistant</span>
              </div>
              <div className="bg-surface text-on-surface p-6 rounded-[28px] rounded-tl-sm border border-surface-container-highest shadow-sm">
                 <div className="flex items-center gap-1.5 opacity-60">
                    <div className="w-2 h-2 rounded-full bg-primary animate-bounce"></div>
                    <div className="w-2 h-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: '0.15s' }}></div>
                    <div className="w-2 h-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: '0.3s' }}></div>
                 </div>
              </div>
          </div>
        )}
      </div>

      <div className="p-4 md:p-6 bg-surface-container-low border-t border-outline-variant/30">
        <div className="max-w-4xl mx-auto relative">
          <div className="bg-[#F2ECEE] rounded-[28px] p-2 flex items-end gap-2 border-b-2 border-outline-variant focus-within:border-primary-container transition-all shadow-inner">
            <button className="p-3 text-outline hover:text-primary transition-colors rounded-full hover:bg-surface-variant/50">
              <span className="material-symbols-outlined">attach_file</span>
            </button>
            <textarea 
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              className="w-full bg-transparent border-none focus:ring-0 resize-none max-h-32 min-h-[44px] py-3 text-on-surface font-body-lg placeholder:text-outline" 
              placeholder="Ask a follow-up question or request deeper analysis..." 
              rows={1}
            />
            <button 
              onClick={handleSubmit}
              disabled={isLoading || !input.trim()}
              className="p-3 bg-primary text-on-primary rounded-full hover:opacity-90 transition-opacity mb-1 mr-1 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <span className="material-symbols-outlined" style={{ fontVariationSettings: "'FILL' 1" }}>send</span>
            </button>
          </div>
          <div className="text-center mt-3 text-xs text-outline font-label-lg">
            AI generated data. Verify critical numbers.
          </div>
        </div>
      </div>
    </div>
  );
}

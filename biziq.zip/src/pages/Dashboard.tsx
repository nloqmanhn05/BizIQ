export function Dashboard() {
  return (
    <>
      <div className="mb-8">
        <h1 className="font-display-sm text-3xl md:text-4xl text-on-surface mb-2">Dashboard Overview</h1>
        <p className="text-on-surface-variant font-body-lg">Here's what's happening with your business today.</p>
      </div>

      {/* Bento Grid 2x2 */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {/* Card 1: Monthly Revenue */}
        <div className="bg-surface-container-lowest rounded-[28px] p-6 flex flex-col justify-between min-h-[160px] relative overflow-hidden group shadow-sm border border-outline-variant/30">
          <div className="absolute inset-0 bg-primary opacity-5 pointer-events-none transition-opacity group-hover:opacity-10"></div>
          <div className="relative z-10">
            <div className="flex justify-between items-start mb-4">
              <h3 className="font-label-lg text-on-surface-variant">Monthly Revenue</h3>
              <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center text-green-700">
                <span className="material-symbols-outlined">payments</span>
              </div>
            </div>
            <div>
              <div className="font-headline-lg text-3xl text-on-surface mb-1">$48,200</div>
              <div className="flex items-center gap-1 text-green-700 font-label-lg text-sm">
                <span className="material-symbols-outlined text-[16px]">trending_up</span>
                <span>+12.5% vs last month</span>
              </div>
            </div>
          </div>
        </div>

        {/* Card 2: Profit Margin */}
        <div className="bg-surface-container-lowest rounded-[28px] p-6 flex flex-col justify-between min-h-[160px] relative overflow-hidden group shadow-sm border border-outline-variant/30">
          <div className="absolute inset-0 bg-primary opacity-5 pointer-events-none transition-opacity group-hover:opacity-10"></div>
          <div className="relative z-10">
            <div className="flex justify-between items-start mb-4">
              <h3 className="font-label-lg text-on-surface-variant">Profit Margin</h3>
              <div className="w-10 h-10 rounded-full bg-red-100 flex items-center justify-center text-red-700">
                <span className="material-symbols-outlined">pie_chart</span>
              </div>
            </div>
            <div>
              <div className="font-headline-lg text-3xl text-on-surface mb-1">18.4%</div>
              <div className="flex items-center gap-1 text-red-700 font-label-lg text-sm">
                <span className="material-symbols-outlined text-[16px]">trending_down</span>
                <span>-2.1% vs last month</span>
              </div>
            </div>
          </div>
        </div>

        {/* Card 3: Total Expenses */}
        <div className="bg-surface-container-lowest rounded-[28px] p-6 flex flex-col justify-between min-h-[160px] relative overflow-hidden group shadow-sm border border-outline-variant/30">
          <div className="absolute inset-0 bg-primary opacity-5 pointer-events-none transition-opacity group-hover:opacity-10"></div>
          <div className="relative z-10">
            <div className="flex justify-between items-start mb-4">
              <h3 className="font-label-lg text-on-surface-variant">Total Expenses</h3>
              <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-700">
                <span className="material-symbols-outlined">receipt_long</span>
              </div>
            </div>
            <div>
              <div className="font-headline-lg text-3xl text-on-surface mb-1">$39,400</div>
              <div className="flex items-center gap-1 text-on-surface-variant font-label-lg text-sm">
                <span className="material-symbols-outlined text-[16px]">horizontal_rule</span>
                <span>On track with budget</span>
              </div>
            </div>
          </div>
        </div>

        {/* Card 4: Cash Runway */}
        <div className="bg-surface-container-lowest rounded-[28px] p-6 flex flex-col justify-between min-h-[160px] relative overflow-hidden group shadow-sm border border-outline-variant/30">
          <div className="absolute inset-0 bg-primary opacity-5 pointer-events-none transition-opacity group-hover:opacity-10"></div>
          <div className="relative z-10">
            <div className="flex justify-between items-start mb-4">
              <h3 className="font-label-lg text-on-surface-variant">Cash Runway</h3>
              <div className="w-10 h-10 rounded-full bg-amber-100 flex items-center justify-center text-amber-700">
                <span className="material-symbols-outlined">warning</span>
              </div>
            </div>
            <div>
              <div className="font-headline-lg text-3xl text-on-surface mb-1">4.2 mos</div>
              <div className="flex items-center gap-1 text-amber-700 font-label-lg text-sm bg-amber-50 px-2 py-1 rounded-md inline-flex border border-amber-200">
                <span>Requires Attention</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Chart Card */}
      <div className="bg-surface-container-lowest rounded-[28px] p-8 relative overflow-hidden flex flex-col shadow-sm border border-outline-variant/30">
        <div className="absolute inset-0 bg-primary opacity-5 pointer-events-none"></div>
        <div className="relative z-10 flex-1 flex flex-col">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
            <div>
              <h2 className="font-title-lg text-xl font-medium text-on-surface">Revenue vs Benchmark</h2>
              <p className="font-body-lg text-sm text-on-surface-variant mt-1">Year-to-date performance tracking</p>
            </div>
            <div className="flex gap-2">
              <button className="border border-outline-variant rounded-lg px-4 py-2 font-label-lg text-sm flex items-center gap-2 hover:bg-surface-variant transition-colors bg-surface-lowest">
                <span className="material-symbols-outlined text-[18px]">filter_list</span>
                Filter
              </button>
              <button className="border border-outline-variant rounded-lg px-4 py-2 font-label-lg text-sm flex items-center gap-2 hover:bg-surface-variant transition-colors bg-surface-variant">
                12 Months
              </button>
            </div>
          </div>

          <div className="flex-1 min-h-[300px] mt-4 relative flex items-end pt-8 pb-2 pl-2">
            <div className="absolute left-0 top-0 bottom-8 flex flex-col justify-between text-xs text-on-surface-variant h-full py-2">
              <span>$60k</span>
              <span>$40k</span>
              <span>$20k</span>
              <span>$0</span>
            </div>

            <div className="absolute inset-0 flex flex-col justify-between pointer-events-none py-2 ml-10 mb-8 z-0">
              <div className="border-t border-outline-variant/30 w-full"></div>
              <div className="border-t border-outline-variant/30 w-full"></div>
              <div className="border-t border-outline-variant/30 w-full"></div>
              <div className="border-t border-outline-variant/30 w-full"></div>
            </div>

            <div className="w-full h-[300px] flex items-end justify-around relative z-10 ml-10 pb-8">
              <svg className="absolute inset-0 w-full h-full" preserveAspectRatio="none" viewBox="0 0 100 100" style={{ overflow: "visible" }}>
                <path d="M0,80 L16,75 L32,70 L48,65 L64,60 L80,55 L100,50" fill="none" stroke="#c3c6cf" strokeDasharray="4 4" strokeWidth="2"></path>
                <path d="M0,90 L16,85 L32,60 L48,40 L64,45 L80,20 L100,10 L100,100 L0,100 Z" fill="url(#grad1)" opacity="0.2"></path>
                <path d="M0,90 L16,85 L32,60 L48,40 L64,45 L80,20 L100,10" fill="none" stroke="#1A3A5C" strokeLinecap="round" strokeLinejoin="round" strokeWidth="3"></path>
                <circle cx="16" cy="85" fill="#1A3A5C" r="3"></circle>
                <circle cx="32" cy="60" fill="#1A3A5C" r="3"></circle>
                <circle cx="48" cy="40" fill="#1A3A5C" r="3"></circle>
                <circle cx="64" cy="45" fill="#1A3A5C" r="3"></circle>
                <circle cx="80" cy="20" fill="#1A3A5C" r="3"></circle>
                <circle cx="100" cy="10" fill="#1A3A5C" r="3"></circle>
                <defs>
                  <linearGradient id="grad1" x1="0%" x2="0%" y1="0%" y2="100%">
                    <stop offset="0%" style={{ stopColor: "#1A3A5C", stopOpacity: 1 }}></stop>
                    <stop offset="100%" style={{ stopColor: "#1A3A5C", stopOpacity: 0 }}></stop>
                  </linearGradient>
                </defs>
              </svg>
            </div>
            
            <div className="absolute bottom-0 left-10 right-0 flex justify-around w-auto text-xs text-on-surface-variant">
              <span>Jan</span>
              <span>Feb</span>
              <span>Mar</span>
              <span>Apr</span>
              <span>May</span>
              <span>Jun</span>
              <span>Jul</span>
            </div>
          </div>
          
          <div className="flex justify-center gap-6 mt-6">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-primary-container"></div>
              <span className="font-label-lg text-sm text-on-surface-variant">Actual Revenue</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full border-2 border-outline-variant border-dashed"></div>
              <span className="font-label-lg text-sm text-on-surface-variant">Benchmark Target</span>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

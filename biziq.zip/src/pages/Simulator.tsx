export function Simulator() {
  return (
    <>
      <div className="flex flex-col gap-2 mb-8">
        <h1 className="font-display-sm text-3xl md:text-4xl text-on-surface">What-If Scenario Planner</h1>
        <p className="font-body-lg text-on-surface-variant max-w-3xl">
          Adjust inputs below to simulate potential business outcomes across different confidence intervals.
        </p>
      </div>

      {/* Input Controls Card */}
      <div className="bg-surface-container-lowest rounded-[28px] p-8 shadow-sm border border-outline-variant/30 mb-8">
        <h3 className="font-title-lg text-xl font-medium text-on-surface mb-6">Simulation Parameters</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <div className="flex flex-col gap-2">
            <div className="flex justify-between items-center">
              <label className="font-label-lg font-medium text-on-surface-variant">Market Growth Rate</label>
              <span className="font-label-lg text-primary-container font-bold">5.2%</span>
            </div>
            <input type="range" min="0" max="15" step="0.1" defaultValue="5.2" className="w-full h-2 bg-surface-variant rounded-lg appearance-none cursor-pointer accent-primary-container" />
          </div>

          <div className="flex flex-col gap-2">
            <div className="flex justify-between items-center">
              <label className="font-label-lg font-medium text-on-surface-variant">Customer Acquisition Cost</label>
              <span className="font-label-lg text-primary-container font-bold">$125</span>
            </div>
            <input type="range" min="50" max="300" step="5" defaultValue="125" className="w-full h-2 bg-surface-variant rounded-lg appearance-none cursor-pointer accent-primary-container" />
          </div>

          <div className="flex flex-col gap-2">
            <div className="flex justify-between items-center">
              <label className="font-label-lg font-medium text-on-surface-variant">Retention Period (Months)</label>
              <span className="font-label-lg text-primary-container font-bold">24</span>
            </div>
            <input type="range" min="6" max="60" step="1" defaultValue="24" className="w-full h-2 bg-surface-variant rounded-lg appearance-none cursor-pointer accent-primary-container" />
          </div>

          <div className="flex flex-col gap-2">
            <label className="font-label-lg font-medium text-on-surface-variant">Primary Region Focus</label>
            <div className="relative">
              <select className="w-full bg-[#F2ECEE] border-none border-b-2 border-outline-variant rounded-t-md px-4 py-3 font-body-lg text-on-surface focus:ring-0 focus:border-primary-container appearance-none">
                <option>North America</option>
                <option>EMEA</option>
                <option>APAC</option>
              </select>
              <span className="material-symbols-outlined absolute right-3 top-1/2 -translate-y-1/2 text-on-surface-variant pointer-events-none">arrow_drop_down</span>
            </div>
          </div>
        </div>
        
        <div className="mt-8 flex justify-end gap-4">
          <button className="px-6 py-2.5 rounded-full border border-outline text-on-surface-variant font-label-lg font-medium hover:bg-surface-variant transition-colors flex items-center gap-2">
            <span className="material-symbols-outlined text-[18px]">restart_alt</span>
            Reset
          </button>
          <button className="px-6 py-2.5 rounded-full bg-primary-container text-on-primary font-label-lg font-medium hover:opacity-90 transition-opacity flex items-center gap-2 shadow-sm">
            <span className="material-symbols-outlined text-[18px]" style={{ fontVariationSettings: "'FILL' 1" }}>play_arrow</span>
            Run Simulation
          </button>
        </div>
      </div>

      {/* Results Tonal Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-error-container/20 rounded-[28px] p-6 border border-error-container relative overflow-hidden">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-full bg-error-container flex items-center justify-center text-on-error-container">
              <span className="material-symbols-outlined text-[20px]">trending_down</span>
            </div>
            <h4 className="font-title-lg text-lg font-semibold text-on-surface">Pessimistic</h4>
          </div>
          <div className="space-y-1">
            <p className="font-label-lg text-sm text-on-surface-variant">Projected Revenue</p>
            <p className="font-headline-lg text-3xl text-on-surface font-semibold">$2.4M</p>
          </div>
        </div>

        <div className="bg-primary-fixed-dim/20 rounded-[28px] p-6 border border-primary-fixed relative overflow-hidden shadow-sm">
          <div className="absolute top-0 left-0 w-full h-1 bg-primary-container"></div>
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-full bg-primary-container flex items-center justify-center text-on-primary">
              <span className="material-symbols-outlined text-[20px]" style={{ fontVariationSettings: "'FILL' 1" }}>check_circle</span>
            </div>
            <h4 className="font-title-lg text-lg font-bold text-on-surface">Most Likely</h4>
          </div>
          <div className="space-y-1">
            <p className="font-label-lg text-sm text-on-surface-variant">Projected Revenue</p>
            <p className="font-headline-lg text-3xl text-primary-container font-bold">$4.8M</p>
          </div>
        </div>

        <div className="bg-tertiary-fixed/30 rounded-[28px] p-6 border border-tertiary-fixed relative overflow-hidden">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-full bg-tertiary-fixed-dim flex items-center justify-center text-on-tertiary-fixed">
              <span className="material-symbols-outlined text-[20px]">trending_up</span>
            </div>
            <h4 className="font-title-lg text-lg font-semibold text-on-surface">Optimistic</h4>
          </div>
          <div className="space-y-1">
            <p className="font-label-lg text-sm text-on-surface-variant">Projected Revenue</p>
            <p className="font-headline-lg text-3xl text-on-surface font-semibold">$7.1M</p>
          </div>
        </div>
      </div>
    </>
  );
}

import { Link, useLocation } from "react-router";
import { clsx } from "clsx";

interface SidebarProps {
  isOpen?: boolean;
  onClose?: () => void;
}

export function Sidebar({ isOpen, onClose }: SidebarProps) {
  const location = useLocation();

  const links = [
    { to: "/", icon: "dashboard", label: "Dashboard" },
    { to: "/decisions", icon: "lightbulb", label: "Decisions" },
    { to: "/simulator", icon: "science", label: "Simulator" },
    { to: "/chat", icon: "chat", label: "Chat" },
    { to: "/upload", icon: "upload_file", label: "Upload" }
  ];

  return (
    <>
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 md:hidden transition-opacity"
          onClick={onClose}
        />
      )}
      <aside className={clsx(
        "fixed left-0 top-0 h-screen w-72 flex flex-col z-50 bg-surface-container-lowest border-r border-outline-variant transition-transform duration-300 md:translate-x-0",
        isOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="px-6 py-8 flex items-center justify-between">
          <span className="text-primary-container font-headline-lg font-extrabold tracking-tight text-2xl flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center text-on-primary">
              <span className="material-symbols-outlined text-[20px]">query_stats</span>
            </div>
            BizIQ
          </span>
          <button onClick={onClose} className="md:hidden p-2 text-on-surface-variant hover:bg-surface-container rounded-full flex items-center justify-center">
            <span className="material-symbols-outlined">close</span>
          </button>
        </div>
        <nav className="flex-1 overflow-y-auto px-4 gap-2 flex flex-col">
          {links.map((link) => {
            const isActive = location.pathname === link.to;
            return (
              <Link
                key={link.to}
                to={link.to}
                onClick={onClose}
                className={clsx(
                  "flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium text-sm",
                  isActive 
                    ? "bg-primary-container/10 text-primary-container font-bold" 
                    : "text-on-surface-variant hover:bg-surface-container"
                )}
              >
              <span 
                className="material-symbols-outlined"
                style={{ fontVariationSettings: isActive ? "'FILL' 1" : "'FILL' 0" }}
              >
                {link.icon}
              </span>
              {link.label}
            </Link>
          );
        })}
      </nav>
    </aside>
    </>
  );
}

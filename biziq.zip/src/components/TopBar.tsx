import { useLocation } from "react-router";

export function TopBar({ onMenuClick }: { onMenuClick?: () => void }) {
  const location = useLocation();
  const getTitle = () => {
    switch (location.pathname) {
      case "/": return "Dashboard";
      case "/decisions": return "AI Decisions";
      case "/simulator": return "System Simulator";
      case "/chat": return "Chat History";
      case "/upload": return "Data Ingestion";
      default: return "BizIQ";
    }
  };

  return (
    <header className="flex items-center justify-between px-6 h-16 w-full bg-surface-container-lowest border-b border-outline-variant sticky top-0 z-30">
      <div className="flex items-center gap-4">
        <button onClick={onMenuClick} className="md:hidden p-2 text-on-surface-variant hover:bg-surface-container rounded-full transition-colors">
          <span className="material-symbols-outlined">menu</span>
        </button>
        <h1 className="font-title-lg text-primary-container font-semibold tracking-tight">
          {getTitle()}
        </h1>
      </div>
      <div className="flex items-center gap-4">
        <div className="w-10 h-10 rounded-full bg-primary-container/20 flex items-center justify-center text-primary-container font-bold overflow-hidden cursor-pointer">
          <img 
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuCy3KfDJjbYByedCajZwVbwtZLMIcpWxaFk6Ocotm9nhIhUXk4yzZ0iUjDNWjIrKaSAGwztzuBw3IO-CWTO-CoXt2nS26mIU0rpkHEtB8AEGPLbi-gXmozEBBqgAEa3WFUcnQDHTmBqvqpYCFY5Z-YeGnnWugVU8FZyN4QAfd2I6Mug_wJ238-tTzmJQSzVM2QHj8QJPW3Jp69Eve8l8DyEvLeVDgWaH0eD_-3j8Js2bbiX70GV43MLNFfK_k4KpnIspuzGMsSGwIA"
            alt="User Avatar"
            className="w-full h-full object-cover"
          />
        </div>
      </div>
    </header>
  );
}
